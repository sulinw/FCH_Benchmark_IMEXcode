function [phi] = initial_aSym2_R(N,L,eps,symc,R)
a = 3;
b = -eps/2;
c = -eps^2*(~symc);   % symmetric is a logical value (true for symmetric phi).
r = @(t)a+b*cos(6*(t-pi/11))+c*cos(t-3*pi/11); % r(t) is a non-symmetric polar eq
rp = @(t)-6*b*sin(6*(t-pi/11))-c*sin(t-3*pi/11);
%
phi_bar = EqualR_Polar(N,L,r,rp,R); %[phi_bar] = EqualR_Polar(N,L,r,rp,R)
phi = FFT_smoother(phi_bar,N);
end