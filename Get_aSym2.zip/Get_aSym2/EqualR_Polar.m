function [phi_bar] = EqualR_Polar(N,L,r,rp,R)
% This is for uniform width (=2*R) initial data with a Polar equation
% r = r(t) is the equation of the center curve;
% rp = rp(t) is the derivative of r = r(theta) w.r.t the variable t.
% The phi_bar is a non-smooth step function takes values {-1,1}
M = 4*N;   % which is supposed to be the same with M in FFT_smoother.m
hp = L/M;
[xp,yp] = ndgrid(hp:hp:L);

%% WSL: construct the equal-width the region and "discontinus" initial data
if nargin == 4
    R = 0.14725;   % the default half uniform width R
elseif (nargin-3)*(nargin-6) >= 0
    error('EqualR_Polar(N,L,r,rp,R): incorrect # of inputs');
end
xO = @(t)r(t).*cos(t)+R*(rp(t).*sin(t)+r(t).*cos(t))./sqrt((r(t)).^2+(rp(t)).^2); % outer boundary
yO = @(t)r(t).*sin(t)+R*(r(t).*sin(t)-rp(t).*cos(t))./sqrt((r(t)).^2+(rp(t)).^2);
xI = @(t)r(t).*cos(t)-R*(rp(t).*sin(t)+r(t).*cos(t))./sqrt((r(t)).^2+(rp(t)).^2); % inner boundary
yI = @(t)r(t).*sin(t)-R*(r(t).*sin(t)-rp(t).*cos(t))./sqrt((r(t)).^2+(rp(t)).^2);
t = linspace(0,2*pi,501);
xv = [xO(t),NaN,xI(fliplr(t))];
yv = [yO(t),NaN,yI(fliplr(t))];
figure, plot(xv+L/2,yv+L/2,'-r'), axis([0 L 0 L]);
%
[in,~] = inpolygon(xp-L/2,yp-L/2,xv,yv);
phi_bar = zeros(M,M);
phi_bar(in) = 1.0;
phi_bar(~in) = -1.0;
end