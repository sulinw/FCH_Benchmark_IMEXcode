function [phi] = FFT_smoother(phi_bar,N)
% this code smoothes phi_bar by using the FFT technique described by Steven
% which makes the output=phi to be smooth and periodic.
M = 4*N;
alpha_alias = (2/M)*[0:M/2-1,M/2,-M/2+1:-1];
[ita1,ita2] = meshgrid(alpha_alias);
alpha_filt = 50*log(10);
filt_xy = exp(-alpha_filt*(ita1.^2+ita2.^2));
%
phi_bar_hat = fft2(phi_bar);
phi_prime = real(ifft2(filt_xy.*phi_bar_hat));
phi = phi_prime(M/N:M/N:M,M/N:M/N:M);  % the smoothed initial data
end